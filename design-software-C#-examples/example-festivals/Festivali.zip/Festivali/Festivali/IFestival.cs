﻿using Festivali.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Festivali
{
    public  interface IFestival
    {
        List<int> dajSveGodine();
        List<Festival> dajFesivalePoGodini(int godina);
        List<int> dajDaneFestivala(int godina, int idFestivala);

        List<Posetilac> dajPosetioce(int godina, int idFestivala, int dan);

        List<Poseta> dajPosete(int idPosetioca);
    }
}
