﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Festivali
{
    public class FestivalFactory
    {
        public static IFestival Festival(string baza)
        {
            switch (baza)
            {
                case "sql":
                    return new FestivaliDb();
                    break;
                case "nosql":
                    return new FestivaliNoSql();
                    break;
                default:
                    return new FestivaliDb();
            }
        }
    }
}
