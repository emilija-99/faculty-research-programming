﻿using Festivali.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Festivali
{
    public class Poseta
    {
        public string nazivFestivala;
        public int godina;
        public int cena;
        public int dan;

        public Poseta(string nazivFestivala, int godina, int cena, int dan)
        {
            this.nazivFestivala = nazivFestivala;
            this.godina = godina;
            this.cena = cena;
            this.dan = dan;
        }
    }
}
