﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Festivali.Models
{
    public class Festival
    {
        public int id;
        public string naziv;


        public Festival(int id, string naziv)
        {
            this.id = id;
            this.naziv = naziv;
        }

        public override string ToString()
        {
            return naziv;
        }

    }
}
