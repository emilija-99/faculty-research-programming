﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Festivali.Models
{
    public class Posetilac
    {
        public int id;
        public string ime;

        public Posetilac(int id, string ime)
        {
            this.id = id;
            this.ime = ime;
        }

        public override string ToString()
        {
            return ime;
        }
    }
}
