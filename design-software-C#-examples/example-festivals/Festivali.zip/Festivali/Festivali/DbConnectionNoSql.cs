﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Festivali
{
    public class DbConnectionNoSql
    {
        private static SqlConnection _connection = null;

        public static SqlConnection Connection
        {
            get
            {
                if (_connection == null)
                    _connection = new SqlConnection(@"Data Source=(localdb)\baza; Initial Catalog = festivali_nosql; Integrated Security = True");
                return _connection;
            }
        }
    }
}
